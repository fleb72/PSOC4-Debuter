/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>
volatile uint8 flagEOC = 0;
volatile int16 result = 0;

CY_ISR(ADCEOC) { // code d'interruption
      /* result = valeur issue de la conversion analogique-numérique
      result en 0 et 4095
      on met un drapeau (flag) à 1 pour signaler
      qu'une conversion est terminée */
      result = ADC_SAR_Seq_1_GetResult16(0);
      flagEOC = 1;
    }

int main() {
    CyGlobalIntEnable; /* Enable global interrupts */
    isr_1_StartEx(ADCEOC);
    
    ADC_SAR_Seq_1_Start();
    ADC_SAR_Seq_1_Enable();
    ADC_SAR_Seq_1_StartConvert();
    
    UART_Debug_Start();
    
    PWM_1_Start(); // Démarrage du générateur PWM
    
    for (;;) { // boucle principale
        if (flagEOC) { // si un résultat est disponible
            flagEOC = 0;
            char8 s[12];
            sprintf(s,"%u\r\n",result);
            UART_Debug_UartPutString(s); // on l'envoie vers le terminal Série
            PWM_1_WriteCompare(result); // modification du paramètre Compare du PWM
        }
    }
}
/* [] END OF FILE */
