/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    CapSense_1_TunerStart();
    CapSense_1_EnableWidget(CapSense_1_PROXIMITYSENSOR0__PROX);
/* All widgets are enabled by default except proximity widgets.
* Proximity widgets must be manually enabled by calling
* CapSense_1_EnableWidget() API, as their long scan time is
* incompatible with the fast response required of other widget
* types.
*/
    while(1)
    {
        CapSense_1_TunerComm();
    }
}

/* [] END OF FILE */
