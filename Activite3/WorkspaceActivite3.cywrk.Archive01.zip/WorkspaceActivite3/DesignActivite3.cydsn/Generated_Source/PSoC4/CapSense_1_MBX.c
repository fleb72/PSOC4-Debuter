/*******************************************************************************
* File Name: CapSense_1_MBX.c
* Version 2.60
*
* Description:
*  This file provides the source code of Tuner communication APIs for the
*  CapSense CSD component.
*
* Note:
*
********************************************************************************
* Copyright 2013-2016, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "CapSense_1_MBX.h"
#include "cyapicallbacks.h"

/*******************************************************************************
*  Place your includes, defines and code here
********************************************************************************/
/* `#START CapSense_1_MBX` */

/* `#END` */

#if (CapSense_1_TUNING_METHOD == CapSense_1__TUNING_MANUAL)
    /*******************************************************************************
    * Function Name: CapSense_1_InitCsdParams
    ********************************************************************************
    *
    * Summary:
    *  Configures the CSD parameters to match the parameters in the inbox.
    *  Used only in the manual tuning mode to apply new scanning parameters from the Tuner
    *  GUI.
    *
    * Parameters:
    *  inbox:  Pointer to Inbox structure in RAM.
    *
    * Return:
    *  None. Contents of the structure are not modified.
    *
    * Global Variables:
    *  CapSense_1_modulationIDAC[]      - stores modulation IDAC values.
    *  CapSense_1_compensationIDAC[]    - stores compensation IDAC values.
    *  CapSense_1_widgetResolution[]    - used to store the scan resolution values for each widget.
    *  CapSense_1_senseClkDividerVal[]  - used to store the sense clock divider values for each widget.
    *  CapSense_1_sampleClkDividerVal[] - used to store the sample clock divider values for each widget.
    *  CapSense_1_fingerThreshold[]     - used to store the finger threshold values for each widget.
    *  CapSense_1_noiseThreshold[]      - used to store the noise threshold values for each widget.
    *  CapSense_1_hysteresis[]          - used to store the hysteresis values for each widget.
    *  CapSense_1_debounce[]            - used to store the debounce values for each widget.
    *
    *******************************************************************************/
    static void CapSense_1_InitCsdParams(volatile const CapSense_1_INBOX *inbox);
    static void CapSense_1_InitCsdParams(volatile const CapSense_1_INBOX *inbox)
    {
        /* Define widget sensor belongs to */
        uint8 sensor = inbox->sensorIndex;
        uint8 widget = CapSense_1_widgetNumber[sensor];

        /* Scanning parameters */
        #if(0u == CapSense_1_AUTOCALIBRATION_ENABLE)
            CapSense_1_modulationIDAC[sensor] = inbox->CapSense_1_inboxCsdCfg.modulatorIDAC;

            #if (CapSense_1_IDAC_CNT == 2u)
                CapSense_1_compensationIDAC[sensor] = inbox->CapSense_1_inboxCsdCfg.compensationIDAC;
            #endif /* ( CapSense_1_IDAC_CNT == 2u ) */
        #endif /* (0u != CapSense_1_AUTOCALIBRATION_ENABLE) */

        CapSense_1_SetIDACRange((uint32)inbox->CapSense_1_inboxCsdCfg.idacRange);

        CapSense_1_widgetResolution[widget] =
        (uint32)(~(CapSense_1_RESOLUTION_16_BITS << inbox->CapSense_1_inboxCsdCfg.scanResolution));

        CapSense_1_widgetResolution[widget] &= CapSense_1_RESOLUTION_16_BITS;

        #if (0u != CapSense_1_MULTIPLE_FREQUENCY_SET )
            CapSense_1_senseClkDividerVal[sensor] = inbox->CapSense_1_inboxCsdCfg.analogSwitchDivider;
            CapSense_1_sampleClkDividerVal[sensor] = inbox->CapSense_1_inboxCsdCfg.modulatorDivider;
        #else
            CapSense_1_senseClkDividerVal = inbox->CapSense_1_inboxCsdCfg.analogSwitchDivider;
            CapSense_1_sampleClkDividerVal = inbox->CapSense_1_inboxCsdCfg.modulatorDivider;
        #endif /* (0u != CapSense_1_MULTIPLE_FREQUENCY_SET ) */

        #if(0u != CapSense_1_CSHL_API_GENERATE)
            #if (0u != CapSense_1_TOTAL_GENERICS_COUNT)
                /* Exclude generic widget */
                if(widget < CapSense_1_END_OF_WIDGETS_INDEX)
                {
            #endif  /* 0u != CapSense_1_TOTAL_GENERICS_COUNT */

                /* High level parameters */
                CapSense_1_fingerThreshold[widget] = inbox->CapSense_1_inboxCsdCfg.fingerThreshold;
                CapSense_1_noiseThreshold[widget]  = inbox->CapSense_1_inboxCsdCfg.noiseThreshold;

                CapSense_1_hysteresis[widget] = inbox->CapSense_1_inboxCsdCfg.hysteresis;
                CapSense_1_debounce[widget]   = inbox->CapSense_1_inboxCsdCfg.debounce;

                #if(CapSense_1_TOTAL_TRACKPAD_GESTURES_COUNT > 0u)
                    CapSense_1_centroidMult[widget] = (uint16)((inbox->CapSense_1_inboxCsdCfg.apiResolution *
                                                            (uint32)CapSense_1_RES_MULT) / (uint32)CapSense_1_numberOfSensors[widget]);

                #endif /* (CapSense_1_TOTAL_TRACKPAD_GESTURES_COUNT > 0u) */

            #if (0u != CapSense_1_TOTAL_GENERICS_COUNT)
                /* Exclude generic widget */
                }
            #endif  /* 0u != CapSense_1_TOTAL_GENERICS_COUNT */

            /* Re-Init baseline */
            CapSense_1_InitializeAllBaselines();
        #endif /* (0u != CapSense_1_CSHL_API_GENERATE) */
    }
#endif  /* (CapSense_1_TUNING_METHOD == CapSense_1__TUNING_MANUAL) */


    /*******************************************************************************
    * Function Name: CapSense_1_InitGesturesParams
    ********************************************************************************
    *
    * Summary:
    *  Configures the parameters of gestures to match the parameters in the inbox.
    *  Used only in the manual and auto tuning mode or if the gestures support is enabled.
    *  Intended apply new scanning parameters from the Tuner GUI.
    *
    * Parameters:
    *  inbox:  Pointer to Inbox structure in RAM.
    *
    * Return:
    *  None. Contents of the structure are not modified.
    *
    *******************************************************************************/
#if((CapSense_1_TUNING_METHOD != CapSense_1__TUNING_NONE) && (0u != CapSense_1_TOTAL_TRACKPAD_GESTURES_COUNT))
    static void CapSense_1_InitGesturesParams(volatile const CapSense_1_INBOX *inbox);
    static void CapSense_1_InitGesturesParams(volatile const CapSense_1_INBOX *inbox)
    {
        #if(0u != CapSense_1_IS_ANY_GESTURES_EN)
            #if(0u != CapSense_1_CLICK_GEST_ENABLED)
                CapSense_1_gesturesConfig.clickRadiusX            = (uint8)inbox->CapSense_1_inboxTmgCfg.clickRadiusX;
                CapSense_1_gesturesConfig.clickRadiusY            = (uint8)inbox->CapSense_1_inboxTmgCfg.clickRadiusY;
                CapSense_1_gesturesConfig.doubleClickRadius       = (uint8)inbox->CapSense_1_inboxTmgCfg.doubleClickRadius;
                CapSense_1_gesturesConfig.STDoubleClickTimeoutMax = inbox->CapSense_1_inboxTmgCfg.stDoubleClickTimeoutMax;
                CapSense_1_gesturesConfig.STDoubleClickTimeoutMin = inbox->CapSense_1_inboxTmgCfg.stDoubleClickTimeoutMin;
                CapSense_1_gesturesConfig.STClickTimeoutMax       = inbox->CapSense_1_inboxTmgCfg.stClickTimeoutMax;
                CapSense_1_gesturesConfig.STClickTimeoutMin       = inbox->CapSense_1_inboxTmgCfg.stClickTimeoutMin;
                CapSense_1_gesturesConfig.DTClickTimeoutMax       = inbox->CapSense_1_inboxTmgCfg.dtClickTimeoutMax;
                CapSense_1_gesturesConfig.DTClickTimeoutMin       = inbox->CapSense_1_inboxTmgCfg.dtClickTimeoutMin;
            #endif /* (0u != CapSense_1_CLICK_GEST_ENABLED) */

            #if(0u != CapSense_1_ZOOM_GEST_ENABLED)
                CapSense_1_gesturesConfig.dtScrollToZoomDebounce  = inbox->CapSense_1_inboxTmgCfg.dtPanToZoomDebounce;
                CapSense_1_gesturesConfig.DTZoomDebounce          = inbox->CapSense_1_inboxTmgCfg.dtZoomDebounce;
                CapSense_1_gesturesConfig.zoomActiveDistanceX     = inbox->CapSense_1_inboxTmgCfg.zoomActiveDistanceX;
                CapSense_1_gesturesConfig.zoomActiveDistanceY     = inbox->CapSense_1_inboxTmgCfg.zoomActiveDistanceY;
            #endif /* (0u != CapSense_1_ZOOM_GEST_ENABLED) */

            #if(0u != CapSense_1_ST_SCROLL_GEST_ENABLED)
                CapSense_1_gesturesConfig.stScrollDebounce        = inbox->CapSense_1_inboxTmgCfg.stScrDebounce;

                CapSense_1_gesturesConfig.stScrollThreshold1X     = inbox->CapSense_1_inboxTmgCfg.stScrThreshold1X;
                CapSense_1_gesturesConfig.stScrollThreshold2X     = inbox->CapSense_1_inboxTmgCfg.stScrThreshold2X;
                CapSense_1_gesturesConfig.stScrollThreshold3X     = inbox->CapSense_1_inboxTmgCfg.stScrThreshold3X;
                CapSense_1_gesturesConfig.stScrollThreshold4X     = inbox->CapSense_1_inboxTmgCfg.stScrThreshold4X;
                CapSense_1_gesturesConfig.stScrollThreshold1Y     = inbox->CapSense_1_inboxTmgCfg.stScrThreshold1Y;
                CapSense_1_gesturesConfig.stScrollThreshold2Y     = inbox->CapSense_1_inboxTmgCfg.stScrThreshold2Y;
                CapSense_1_gesturesConfig.stScrollThreshold3Y     = inbox->CapSense_1_inboxTmgCfg.stScrThreshold3Y;
                CapSense_1_gesturesConfig.stScrollThreshold4Y     = inbox->CapSense_1_inboxTmgCfg.stScrThreshold4Y;
                CapSense_1_gesturesConfig.stScrollStep1           = inbox->CapSense_1_inboxTmgCfg.stScrStep1;
                CapSense_1_gesturesConfig.stScrollStep2           = inbox->CapSense_1_inboxTmgCfg.stScrStep2;
                CapSense_1_gesturesConfig.stScrollStep3           = inbox->CapSense_1_inboxTmgCfg.stScrStep3;
                CapSense_1_gesturesConfig.stScrollStep4           = inbox->CapSense_1_inboxTmgCfg.stScrStep4;
                CapSense_1_gesturesConfig.stInScrActiveDistanceX  = inbox->CapSense_1_inboxTmgCfg.stInScrActiveDistanceX;
                CapSense_1_gesturesConfig.stInScrActiveDistanceY  = inbox->CapSense_1_inboxTmgCfg.stInScrActiveDistanceY;
                CapSense_1_gesturesConfig.stInScrCountLevel       = inbox->CapSense_1_inboxTmgCfg.stInScrCountLevel;
            #endif /* (0u != CapSense_1_ST_SCROLL_GEST_ENABLED) */

            #if(0u != CapSense_1_DT_SCROLL_GEST_ENABLED)
                CapSense_1_gesturesConfig.dtScrollDebounce        = inbox->CapSense_1_inboxTmgCfg.dtScrDebounce;
                CapSense_1_gesturesConfig.dtScrollThreshold1X     = inbox->CapSense_1_inboxTmgCfg.dtScrThreshold1X;
                CapSense_1_gesturesConfig.dtScrollThreshold2X     = inbox->CapSense_1_inboxTmgCfg.dtScrThreshold2X;
                CapSense_1_gesturesConfig.dtScrollThreshold3X     = inbox->CapSense_1_inboxTmgCfg.dtScrThreshold3X;
                CapSense_1_gesturesConfig.dtScrollThreshold4X     = inbox->CapSense_1_inboxTmgCfg.dtScrThreshold4X;
                CapSense_1_gesturesConfig.dtScrollThreshold1Y     = inbox->CapSense_1_inboxTmgCfg.dtScrThreshold1Y;
                CapSense_1_gesturesConfig.dtScrollThreshold2Y     = inbox->CapSense_1_inboxTmgCfg.dtScrThreshold2Y;
                CapSense_1_gesturesConfig.dtScrollThreshold3Y     = inbox->CapSense_1_inboxTmgCfg.dtScrThreshold3Y;
                CapSense_1_gesturesConfig.dtScrollThreshold4Y     = inbox->CapSense_1_inboxTmgCfg.dtScrThreshold4Y;
                CapSense_1_gesturesConfig.dtScrollStep1           = inbox->CapSense_1_inboxTmgCfg.dtScrStep1;
                CapSense_1_gesturesConfig.dtScrollStep2           = inbox->CapSense_1_inboxTmgCfg.dtScrStep2;
                CapSense_1_gesturesConfig.dtScrollStep3           = inbox->CapSense_1_inboxTmgCfg.dtScrStep3;
                CapSense_1_gesturesConfig.dtScrollStep4           = inbox->CapSense_1_inboxTmgCfg.dtScrStep4;
                CapSense_1_gesturesConfig.dtInScrActiveDistanceX  = inbox->CapSense_1_inboxTmgCfg.dtInScrActiveDistanceX;
                CapSense_1_gesturesConfig.dtInScrActiveDistanceY  = inbox->CapSense_1_inboxTmgCfg.dtInScrActiveDistanceY;
                CapSense_1_gesturesConfig.dtInScrCountLevel       = inbox->CapSense_1_inboxTmgCfg.dtInScrCountLevel;
            #endif /* (0u != CapSense_1_DT_SCROLL_GEST_ENABLED) */

            #if(0u != CapSense_1_FLICK_GEST_ENABLED)
                CapSense_1_gesturesConfig.flickSampleTime         = inbox->CapSense_1_inboxTmgCfg.flickSampleTime;
                CapSense_1_gesturesConfig.flickActiveDistanceX    = inbox->CapSense_1_inboxTmgCfg.flickActiveDistanceX;
                CapSense_1_gesturesConfig.flickActiveDistanceY    = inbox->CapSense_1_inboxTmgCfg.flickActiveDistanceY;
            #endif /* (0u != CapSense_1_FLICK_GEST_ENABLED) */

            #if(0u != CapSense_1_ROTATE_GEST_ENABLED)
                CapSense_1_gesturesConfig.rotateDebounce          = inbox->CapSense_1_inboxTmgCfg.rotateDebounce;
            #endif /* (0u != CapSense_1_ROTATE_GEST_ENABLED) */

            #if(0u != CapSense_1_EDGE_SWIPE_GEST_ENABLED)
                CapSense_1_gesturesConfig.edgeSwipeActiveDistance = inbox->CapSense_1_inboxTmgCfg.edgeSwipeActiveDistance;
                CapSense_1_gesturesConfig.bottomAngleThreshold    = inbox->CapSense_1_inboxTmgCfg.bottomAngleThreshold;
                CapSense_1_gesturesConfig.edgeSwipeTimeout        = inbox->CapSense_1_inboxTmgCfg.edgeSwipeTime;
                CapSense_1_TMG_edgeSwipeCompleteTimeout           = inbox->CapSense_1_inboxTmgCfg.edgeSwipeCompleteTimeout;
                CapSense_1_gesturesConfig.topAngleThreshold       = inbox->CapSense_1_inboxTmgCfg.topAngleThreshold;
                CapSense_1_gesturesConfig.widthOfDisambiguation   = inbox->CapSense_1_inboxTmgCfg.widthOfDisambiguation;
            #endif /* (0u != CapSense_1_EDGE_SWIPE_GEST_ENABLED) */

            CapSense_1_TMG_InitGestures(&CapSense_1_gesturesConfig);
        #endif /* (0u != CapSense_1_IS_ANY_GESTURES_EN) */

        #if(0u != CapSense_1_TP_GESTURE_POS_FILTERS_MASK)
            CapSense_1_posFiltersMask[CapSense_1_TRACKPAD__TPG] = inbox->CapSense_1_inboxTmgCfg.filtersMask;
        #endif /* (0u != CapSense_1_TP_GESTURE_POS_FILTERS_MASK) */

        #if(0u != (CapSense_1_XY_ADAPTIVE_IIR_MASK & CapSense_1_TP_GESTURE_POS_FILTERS_MASK))
            CapSense_1_adpFltOptions.divVal       = inbox->CapSense_1_inboxTmgCfg.filterDivisor;
            CapSense_1_adpFltOptions.largeMovTh   = inbox->CapSense_1_inboxTmgCfg.largeMovThreshold;
            CapSense_1_adpFltOptions.littleMovTh  = inbox->CapSense_1_inboxTmgCfg.littleMovThreshold;
            CapSense_1_adpFltOptions.maxK     = inbox->CapSense_1_inboxTmgCfg.maxFilterCoef;
            CapSense_1_adpFltOptions.minK     = inbox->CapSense_1_inboxTmgCfg.minFilterCoef;
            CapSense_1_adpFltOptions.noMovTh      = inbox->CapSense_1_inboxTmgCfg.noMovThreshold;
        #endif /* (0u != (CapSense_1_XY_ADAPTIVE_IIR_MASK & CapSense_1_TP_GESTURE_POS_FILTERS_MASK)) */
    }
#endif /* ((CapSense_1_TUNING_METHOD != CapSense_1__TUNING_NONE) && (0u != CapSense_1_TOTAL_TRACKPAD_GESTURES_COUNT)) */


/*******************************************************************************
* Function Name: CapSense_1_InitMailbox
********************************************************************************
*
* Summary:
*  Initializes parameters of the mailbox structure.
*  Sets the type and size of the mailbox structure.
*  Sets a check sum to check by the Tuner GUI and noReadMsg flag to indicate that this
*  is the first communication packet.
*
* Parameters:
*  mbx:  Pointer to Mailbox structure in RAM.
*
* Return:
*  None. Modifies the contents of mbx and mbx->outbox.
*
* Global Variables:
*  None
*
*******************************************************************************/
void CapSense_1_InitMailbox(volatile CapSense_1_MAILBOX *mbx)
{
    /* Restore TYPE_ID (clear busy flag) to indicate "action complete" */
    mbx->type = CapSense_1_TYPE_ID;
    /* Restore default value - clear "have_msg" */
    mbx->size = sizeof(CapSense_1_MAILBOX);

    /* Additional fields for async and reset handling */
    #if((CapSense_1_TUNING_METHOD != CapSense_1__TUNING_NONE) && (0u != CapSense_1_TOTAL_TRACKPAD_GESTURES_COUNT) ||\
        (CapSense_1_TUNING_METHOD == CapSense_1__TUNING_MANUAL))
        mbx->outbox.noReadMessage = 1u;
    #endif  /* ((CapSense_1_TUNING_METHOD != CapSense_1__TUNING_NONE) && (0u != CapSense_1_TOTAL_TRACKPAD_GESTURES_COUNT) ||\
                (CapSense_1_TUNING_METHOD == CapSense_1__TUNING_MANUAL)) */

    mbx->outbox.checkSum = (uint16)(CapSense_1_CHECK_SUM);
}


/*******************************************************************************
* Function Name:  CapSense_1_PostMessage
********************************************************************************
*
* Summary:
*  This blocking function waits while the Tuner GUI reports that the mailbox content
*  could be modified (clears CapSense_1_BUSY_FLAG). Then loads the report
*  data to the outbox and sets a busy flag.
*  In the manual tuning mode the report data is:
*    - raw data, baseline, signal;
*  In the auto tuning mode the added data is:
*    - fingerThreshold;
*    - noiseThreshold;
*    - scanResolution;
*    - idacValue;
*    - prescaler.
*
* Parameters:
*  mbx:  Pointer to Mailbox structure in RAM.
*
* Return:
*  None. Modifies the contents of mbx->outbox.
*
* Global Variables:
*  None
*
*******************************************************************************/
void CapSense_1_PostMessage(volatile CapSense_1_MAILBOX *mbx)
{
    uint8 i;

    #if ( CapSense_1_TUNING_METHOD == CapSense_1__TUNING_AUTO )
        uint8 tmpResolutionIndex;
        uint16 tmpResolutionValue;
    #endif /* ( CapSense_1_TUNING_METHOD == CapSense_1__TUNING_AUTO ) */

    /* Check busy flag */
    while (mbx->type != CapSense_1_TYPE_ID){}

    /* Copy scan parameters */
    #if((CapSense_1_TUNING_METHOD == CapSense_1__TUNING_AUTO) || (0u != CapSense_1_AUTOCALIBRATION_ENABLE))
        /* Copy tuned idac values */
        for(i = 0u; i < CapSense_1_TOTAL_SENSOR_COUNT; i++)
        {
            mbx->outbox.modulationIDAC[i] = CapSense_1_modulationIDAC[i];
            #if (CapSense_1_IDAC_CNT == 2u)
                mbx->outbox.compensationIDAC[i] = CapSense_1_compensationIDAC[i];
            #endif /* (CapSense_1_IDAC_CNT == 2u) */
        }
    #endif /* ((CapSense_1_TUNING_METHOD == CapSense_1__TUNING_AUTO) || (0u != CapSense_1_AUTOCALIBRATION_ENABLE)) */

    #if ( CapSense_1_TUNING_METHOD == CapSense_1__TUNING_AUTO )
        for(i = 0u; i < CapSense_1_TOTAL_SCANSLOT_COUNT; i++)
        {
            mbx->outbox.analogSwitchDivider[i] = CapSense_1_senseClkDividerVal[i];
            mbx->outbox.modulatorDivider[i] = CapSense_1_sampleClkDividerVal[i];
        }

        /* Widget resolution, take to account TP and MB */
        for(i = 0u; i < CapSense_1_WIDGET_RESOLUTION_PARAMETERS_COUNT; i++)
        {
            tmpResolutionValue = (uint16)(CapSense_1_widgetResolution[i] >> CapSense_1_MSB_RESOLUTION_OFFSET);
            tmpResolutionIndex = 0u;

            while(0u != tmpResolutionValue)
            {
                tmpResolutionIndex++;
                tmpResolutionValue >>= 1u;
            }

            mbx->outbox.scanResolution[i] = tmpResolutionIndex;
        }

        #if(0u != CapSense_1_CSHL_API_GENERATE)
            /* Parameters are changed in run time */
            for(i = 0u; i < CapSense_1_WIDGET_CSHL_PARAMETERS_COUNT; i++)
            {
                mbx->outbox.fingerThreshold[i] = CapSense_1_fingerThreshold[i];
                mbx->outbox.noiseThreshold[i]  = CapSense_1_noiseThreshold[i];
                mbx->outbox.hysteresis[i]      = CapSense_1_hysteresis[i];
            }
        #endif /* (0u != CapSense_1_CSHL_API_GENERATE) */

    #endif /* (CapSense_1_TUNING_METHOD == CapSense_1__TUNING_AUTO) */


    /* Copy all data - Raw, Base, Signal, OnMask */
    for(i = 0u; i < CapSense_1_TOTAL_SENSOR_COUNT; i++)
    {
        mbx->outbox.rawData[i]  = CapSense_1_sensorRaw[i];
        #if(0u != CapSense_1_CSHL_API_GENERATE)
            mbx->outbox.baseLine[i] = CapSense_1_sensorBaseline[i];
            #if (CapSense_1_SIGNAL_SIZE == CapSense_1_SIGNAL_SIZE_UINT8)
                mbx->outbox.sensorSignal[i]   = (uint8)CapSense_1_sensorSignal[i];
            #else
                mbx->outbox.sensorSignal[i]   = (uint16)CapSense_1_sensorSignal[i];
            #endif  /* (CapSense_1_SIGNAL_SIZE == CapSense_1_SIGNAL_SIZE_UINT8) */
        #endif /* (0u != CapSense_1_CSHL_API_GENERATE) */
    }

    /* Set busy flag */
    mbx->type = CapSense_1_BUSY_FLAG;
}


#if ((CapSense_1_TUNING_METHOD != CapSense_1__TUNING_NONE) && (0u != CapSense_1_TOTAL_TRACKPAD_GESTURES_COUNT) ||\
     (CapSense_1_TUNING_METHOD == CapSense_1__TUNING_MANUAL))

    /*******************************************************************************
    * Function Name: CapSense_1_ReadMessage
    ********************************************************************************
    *
    * Summary:
    *  If CapSense_1_HAVE_MSG is found in the mailbox, the function initializes
    *   the component with parameters which are found in the inbox.
    *   Signal is DONE by overwriting the value in the mailbox size field.
    *  Only available in the manual tuning mode.
    *
    * Parameters:
    *  mbx:  Pointer to Mailbox structure in RAM.
    *
    * Return:
    *  None. Modifies the contents of mbx.
    *
    * Global Variables:
    *  None
    *
    *******************************************************************************/
    void CapSense_1_ReadMessage(volatile CapSense_1_MAILBOX *mbx)
    {
        volatile CapSense_1_INBOX *tmpInbox;

        /* Do we have a message waiting? */
        if ((mbx->size) == CapSense_1_HAVE_MSG)
        {
            tmpInbox = &(mbx->inbox);

            #if(CapSense_1_TUNING_METHOD == CapSense_1__TUNING_MANUAL)
                if(tmpInbox->sensorIndex != CapSense_1_MAX_UINT_8)
                {
                    CapSense_1_InitCsdParams(tmpInbox);
                }
            #endif /* (CapSense_1_TUNING_METHOD == CapSense_1__TUNING_MANUAL) */

            #if(0u != CapSense_1_TOTAL_TRACKPAD_GESTURES_COUNT)
                if(tmpInbox->sensorIndex == CapSense_1_MAX_UINT_8)
                {
                    CapSense_1_InitGesturesParams(tmpInbox);
                }
            #endif /* (0u != CapSense_1_TOTAL_TRACKPAD_GESTURES_COUNT) */

            /* Notify host/tuner that we have consumed message */
            mbx->size = sizeof(CapSense_1_MAILBOX);

            /* Default settings were changed */
            mbx->outbox.noReadMessage = 0u;

            /* `#START CapSense_1_MBX_READ_MSG` */

            /* `#END` */

            #ifdef CapSense_1_READ_MESSAGE_MBX_READ_MSG_CALLBACK
                CapSense_1_ReadMessage_MBX_READ_MSG_Callback();
            #endif /* CapSense_1_READ_MESSAGE_MBX_READ_MSG_CALLBACK */
        }
    }
#endif  /* ((CapSense_1_TUNING_METHOD != CapSense_1__TUNING_NONE) && (0u != CapSense_1_TOTAL_TRACKPAD_GESTURES_COUNT) ||\
            (CapSense_1_TUNING_METHOD == CapSense_1__TUNING_MANUAL)) */


/* [] END OF FILE */
