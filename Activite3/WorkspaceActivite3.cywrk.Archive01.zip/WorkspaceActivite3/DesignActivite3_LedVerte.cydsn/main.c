/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>

int main()
{
/* Enable global interrupt. */
CyGlobalIntEnable; 
/* Enable and start the CapSense block. */
CapSense_Start();
/* Initialize the baselines of the proximity sensor. */
CapSense_InitializeSensorBaseline(CapSense_PROXIMITYSENSOR0__PROX);
/* Update the baseline of the proximity sensor. */
CapSense_UpdateSensorBaseline(CapSense_PROXIMITYSENSOR0__PROX);
/* Scan the proximity sensor. */         
CapSense_ScanSensor(CapSense_PROXIMITYSENSOR0__PROX);

UART_Debug_Start();

for(;;)
    {
        if (!CapSense_IsBusy())
        {
            /* Check if proximity sensor is active. */
            uint8 proximity = CapSense_CheckIsSensorActive(CapSense_PROXIMITYSENSOR0__PROX);
            if(proximity)
            {
                Pin_GreenLED_Write(0); /* Switch on the LED if proximity is detected */
                /* Serial debug */
                char8 s[20];
                sprintf(s,"%u\r\n",CapSense_SensorRaw[0]);
                UART_Debug_UartPutString(s);
            }
            else /* Proximity sensor is inactive. */
            {
                /* Switch off the LED if proximity is not detected. */
                Pin_GreenLED_Write(1);
            }
            /* Update the baseline of the proximity sensor. */
            CapSense_UpdateSensorBaseline(CapSense_PROXIMITYSENSOR0__PROX);
            /* Scan the proximity sensor. */       
            CapSense_ScanSensor(CapSense_PROXIMITYSENSOR0__PROX); 
        }
    }  
}

/* [] END OF FILE */
