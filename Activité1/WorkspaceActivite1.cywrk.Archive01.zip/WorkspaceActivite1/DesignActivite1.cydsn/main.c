/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    for(;;)
    {
        /* Place your application code here. */
        Pin_RedLed_Write(0);    // Allumer la LED rouge
        Pin_GreenLed_Write(1);  // Eteindre la LED verte
        CyDelay(1000);          // pause 1s
        Pin_RedLed_Write(1);    // Eteindre la LED rouge
        Pin_GreenLed_Write(0);  // Allumer la LED verte
        CyDelay(1000);          // pause 1s
    }
}

/* [] END OF FILE */
