/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

CY_ISR(GestionnaireDetectionAppui) { /* Code d’interruption */
    UART_Debug_UartPutString("Detection Appui\r\n");
    RedLed_Write(~RedLed_Read());  /* bascule On/Off */
    SW2_ClearInterrupt();
}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    isr_1_StartEx(GestionnaireDetectionAppui);
    UART_Debug_Start();
    
    UART_Debug_UartPutString("Hello World\r\n");
    
    for(;;) /* boucle infinie */
    {
        /* Place your application code here. */
    }
}


/* [] END OF FILE */
